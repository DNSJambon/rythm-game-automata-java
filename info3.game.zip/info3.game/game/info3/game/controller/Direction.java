package info3.game.controller;

/* Direction absolue du modèle.
 */

 public enum Direction {
    Nord,Sud,Est,Ouest;
}
