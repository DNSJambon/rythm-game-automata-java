package info3.game.controller;

/* Direction relative a l'entité.
 */

public enum DirRelative {
    Devant, Gauche, Droite, Derriere, soi;
    
}
